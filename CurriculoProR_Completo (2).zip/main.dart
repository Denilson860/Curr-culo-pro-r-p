
import 'package:flutter/material.dart';

void main() {
  runApp(CurriculoProRApp());
}

class CurriculoProRApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Currículo Pro-R',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Colors.grey[100],
      ),
      home: CurriculumStepOne(),
    );
  }
}

class CurriculumStepOne extends StatefulWidget {
  @override
  _CurriculumStepOneState createState() => _CurriculumStepOneState();
}

class _CurriculumStepOneState extends State<CurriculumStepOne> {
  final _formKey = GlobalKey<FormState>();
  final nameController = TextEditingController();
  final emailController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Currículo Pro-R')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Passo 1: Dados Pessoais', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              TextFormField(
                controller: nameController,
                decoration: InputDecoration(labelText: 'Nome completo'),
                validator: (value) => value == null || value.isEmpty ? 'Insira seu nome' : null,
              ),
              TextFormField(
                controller: emailController,
                decoration: InputDecoration(labelText: 'Email'),
                validator: (value) => value == null || !value.contains('@') ? 'Insira um email válido' : null,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Dados salvos com sucesso.')));
                  }
                },
                child: Text('Próximo'),
              )
            ],
          ),
        ),
      ),
    );
  }
}
